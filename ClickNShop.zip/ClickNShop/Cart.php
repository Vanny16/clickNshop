<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>shopping cart</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

   <link rel="stylesheet" href="index.css">

</head>
<body>
   


<section class="shopping-cart">

   <h1 class="title">products added</h1>


   <div class="cart-total">
      <a href="shop.php" class="option-btn">continue shopping</a>
      <a href="cart.php?delete_all" class="delete-btn">delete all</a>
      <a href="checkout.php" class="btn">proceed to checkout</a>
   </div>

</section>









<script src="js/script.js"></script>

</body>
</html>