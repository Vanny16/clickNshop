<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ClickNShop</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="fruitscss.css">

</head>
<body>

<!---------------------------------------------------NAVBAR--------------------------------------------------->

<header>
    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>

    <a class="logo">Click N' Shop Market </a>
    
    <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="Fruits.php">Fruits</a>
        <a href="Meats.php">Meats</a>
        <a href="Seafood.php">Seafood</a>
        <a href="index.php#contact">Contacts</a>
    </nav>

    <div class="icons">
        <a href="#" class="fas fa-bars"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
        <a href="#" class="fas fa-user"></a>
        
    </div>
</header>

<!---------------------------------------------------PRODUCTS--------------------------------------------------->

<section class="products" id="products">
    <h1 class="heading2"><span> Fruit </span>Products</h1>
    <h1 class="heading"><span> Vegetables </span>Products</h1>

    <div class="box-container">

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Vegetables/ampalaya.jpg" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Ampalaya</h3>
                <h2>(Per 500g)</h2>
                <div class="price"> 90.00 <span>₱00.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Vegetables/Asparagus.jpg" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Asparagus</h3>
                <h2>(Per 250g)</h2>
                <div class="price"> ₱219.00 <span>₱235.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-13%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Vegetables/cabbage.jpg" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Cabbage</h3>
                <h2>(Per Piece)</h2>
                <div class="price"> ₱117.00 <span>₱130.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Vegetables/okra.jpeg" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Okra</h3>
                <h2>(Per Bundle)</h2>
                <div class="price"> ₱20.00 <span>₱00.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Vegetables/pechay.jpg" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Pechay Tagalog</h3>
                <h2>(Per 250g)</h2>
                <div class="price"> ₱60.00 <span>₱00.00</span></div>
            </div>
        </div>


    </div>
</section>

<!---------------------------------------------------FOOTER--------------------------------------------------->

<section class="footer">

    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="index.php#home">home</a>
            <a href="index.php#about">about</a>
            <a href="index.php#products">products</a>
            <a href="index.php#review">review</a>
            <a href="index.php#contact">contact</a>
        </div>

        <div class="box">
            <h3>Products</h3>
            <a href="Fruits.php">Fruits</a>
            <a href="Vegetables.php">Vegetables</a>
            <a href="Meats.php">Meats</a>
            <a href="Seafood.php">Seafood</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a>09776157839 / 09165914890</a>
            <a>clicknshop@gmail.com</a>
            <a href="#">Facebook Page</a>
            <a href="#">Instagram Page</a>
            <img src="images/payment.png" alt="">
        </div>

    </div>

</section>

</body>
</html>
