<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ClickNShop</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="fruitscss.css">

</head>
<body>

<!---------------------------------------------------NAVBAR--------------------------------------------------->

<header>
    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>

    <a class="logo">Click N' Shop Market </a>
    
    <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="Vegetables.php">Vegetables</a>
        <a href="Meats.php">Meats</a>
        <a href="Seafood.php">Seafood</a>
        <a href="index.php#contact">Contacts</a>
    </nav>

    <div class="icons">
        <a href="#" class="fas fa-bars"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
        <a href="#" class="fas fa-user"></a>
        
    </div>
</header>

<!---------------------------------------------------PRODUCTS--------------------------------------------------->

<section class="products" id="products">
    <h1 class="heading2"><span> Fruit </span>Products</h1>
    <h1 class="heading"><span> Fruit </span>Products</h1>

    <div class="box-container">

        <div class="box">
            <span class="discount">-25%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/apple.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Apple</h3>
                <h2>(Per Piece)</h2>
                <div class="price"> ₱30.00 <span>₱40.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-20%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/avocado.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Avocado</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱40.00 <span>₱50.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-15%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/BananaLakatan2.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Banana (Lakatan)</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱119.00 <span>₱140.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-10%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/durian.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Durian</h3>
                <h2>(Per Piece)</h2>
                <div class="price"> ₱180.00 <span>₱200.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-7%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/grapes2.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Grapes (Seedless)</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱354.00 <span>₱380.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-20%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/GreenApple.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Green Apple</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱64.00 <span>₱80.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-5%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/GreenMango.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Mango Kalabaw</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱00.00 <span>₱00.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Kiwigold.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Kiwi (Gold)</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱59.00 <span>₱00.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Kiwigreen.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Kiwi (Green)</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱55.00 <span>₱00.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-20%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Lanzones.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Lanzones</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱224.00 <span>₱280.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-30%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Lemon.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Lemon</h3>
                <h2>(Per Piece)</h2>
                <div class="price"> ₱25.00 <span>₱35.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-30%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Mango.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Mango (Ripe)</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱180.00 <span>₱210.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-23%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Melon.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Melon</h3>
                <h2>(Per Kg)</h2>
                <div class="price"> ₱185.00 <span>₱240.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-0%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Orange.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Orange</h3>
                <h2>(Per Piece)</h2>
                <div class="price"> ₱55.00 <span>₱00.00</span></div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-5%</span>
            <div class="image">
                <img src="../ClickNShop/Images/Fruits/Watermelon.png" alt="">
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="cart-btn">Add to Cart</a>
                    <a href="#" class="fas fa-share"></a>
                </div>
            </div>
            <div class="content">
                <h3>Watermelon</h3>
                <h2>(Per Piece)</h2>
                <div class="price"> ₱240.00 <span>₱2.00</span></div>
            </div>
        </div>

    </div>
</section>

<!---------------------------------------------------FOOTER--------------------------------------------------->

<section class="footer">

    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="index.php#home">home</a>
            <a href="index.php#about">about</a>
            <a href="index.php#products">products</a>
            <a href="index.php#review">review</a>
            <a href="index.php#contact">contact</a>
        </div>

        <div class="box">
            <h3>Products</h3>
            <a href="Fruits.php">Fruits</a>
            <a href="Vegetables.php">Vegetables</a>
            <a href="Meats.php">Meats</a>
            <a href="Seafood.php">Seafood</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a> 09776157839 / 09165914890</a>
            <a> clicknshop@gmail.com</a>
            <a href="#">Facebook Page</a>
            <a href="#">Instagram Page</a>
            <img src="images/payment.png" alt="">
        </div>

    </div>

</section>

</body>
</html>
